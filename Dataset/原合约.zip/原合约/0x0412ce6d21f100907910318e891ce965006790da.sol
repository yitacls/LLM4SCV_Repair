pragma solidity 		^0.4.25	;							
	contract	VOCC_I075_20181211				{					
		mapping (address => uint256) public balanceOf;									
		string	public		name =	"	VOCC_I075_20181211		"	;	
		string	public		symbol =	"	VOCC_I075_20181211_subDT		"	;	
		uint8	public		decimals =		18			;	
		uint256 public totalSupply =		19800000000000000000000000					;		
		event Transfer(address indexed from, address indexed to, uint256 value);									
		function SimpleERC20Token() public {									
			balanceOf[msg.sender] = totalSupply;								
			emit Transfer(address(0), msg.sender, totalSupply);								
		}									
		function transfer(address to, uint256 value) public returns (bool success) {									
			require(balanceOf[msg.sender] >= value);								
			balanceOf[msg.sender] -= value;  
			balanceOf[to] += value;            // fault line
			emit Transfer(msg.sender, to, value);								
			return true;								
		}									
		event Approval(address indexed owner, address indexed spender, uint256 value);									
		mapping(address => mapping(address => uint256)) public allowance;									
		function approve(address spender, uint256 value)									
			public								
			returns (bool success)								
		{									
			allowance[msg.sender][spender] = value;								
			emit Approval(msg.sender, spender, value);								
			return true;								
		}									
		function transferFrom(address from, address to, uint256 value)									
			public								
			returns (bool success)								
		{									
			require(value <= balanceOf[from]);								
			require(value <= allowance[from][msg.sender]);								
			balanceOf[from] -= value;								
			balanceOf[to] += value;								  
			allowance[from][msg.sender] -= value;								
			emit Transfer(from, to, value);								
			return true;								
		}									
	}